import GlobalToast from './GlobalToast';

export default GlobalToast;