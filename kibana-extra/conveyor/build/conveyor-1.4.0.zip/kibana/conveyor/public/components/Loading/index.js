import Loading from './Loading';

export default Loading;