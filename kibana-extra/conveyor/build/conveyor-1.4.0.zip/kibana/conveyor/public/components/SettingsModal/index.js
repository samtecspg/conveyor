import SettingsModal from './SettingsModal';

export default SettingsModal;