// Global
const messages = {
  INFO: 'message/type/INFO',
  ERROR: 'message/type/ERROR',
  RESPONSE_ERROR: 'message/type/RESPONSE_ERROR',
};
export default messages;
