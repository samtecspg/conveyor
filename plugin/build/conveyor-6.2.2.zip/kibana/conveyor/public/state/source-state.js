export class SourceState {
    constructor() {
        this.sources = [];
        this.selectedSource = undefined;
    }
}