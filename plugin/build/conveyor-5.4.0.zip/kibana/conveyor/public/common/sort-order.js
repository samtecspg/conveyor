export const SortOrder = {
  ASC: 'ascending',
  DESC: 'descending',
  DEFAULT: 'ascending'
};